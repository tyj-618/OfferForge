package com.offerforge.exception;

import com.offerforge.common.ApiResponse;
import com.offerforge.common.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

/**
 * 全局异常处理：业务码 + HTTP 状态双重表达。
 * 存量业务码保持 HTTP 200（前端拦截器按 body.code 分流），
 * 限流/不可用类新增码同步返回 429/503，便于网关与监控识别。
 * 未映射路径统一返回 404（code=40400），不再落入 500 兜底。
 * 未知异常记录完整堆栈，不向前端暴露技术细节。
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<Void>> handleBusinessException(BusinessException exception) {
        log.warn("business error code={} message={}", exception.errorCode().code(), exception.getMessage());
        return ResponseEntity.status(httpStatus(exception.errorCode()))
                .body(ApiResponse.fail(exception.errorCode().code(), exception.getMessage()));
    }

    /** 免费额度耗尽：429 + 字符串业务码，前端据此引导配置自带 Key */
    @ExceptionHandler(QuotaExceededException.class)
    public ResponseEntity<QuotaExceededBody> handleQuotaExceededException(QuotaExceededException exception) {
        log.warn("quota exceeded remaining={} message={}", exception.remainingQuota(), exception.getMessage());
        return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                .body(QuotaExceededBody.of(exception.remainingQuota(), exception.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ApiResponse<Void> handleValidationException(MethodArgumentNotValidException exception) {
        FieldError fieldError = exception.getBindingResult().getFieldError();
        String message = fieldError == null
                ? ErrorCode.PARAM_ERROR.message()
                : "参数 " + fieldError.getField() + " " + fieldError.getDefaultMessage();
        return ApiResponse.fail(ErrorCode.PARAM_ERROR.code(), message);
    }

    /** 数据库访问失败：返回 503；进行中的面试上下文在 Redis/内存，不受影响 */
    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<ApiResponse<Void>> handleDataAccessException(DataAccessException exception) {
        log.error("data access error", exception);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(ApiResponse.fail(ErrorCode.SERVICE_UNAVAILABLE.code(), ErrorCode.SERVICE_UNAVAILABLE.message()));
    }

    /** 未映射路径（含已下线端点如 /followup）：默认静态资源处理器找不到资源时抛出，统一 404 + 40400 */
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNoResourceFound(NoResourceFoundException exception) {
        log.warn("no resource found: {} {}", exception.getHttpMethod(), exception.getResourcePath());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiResponse.fail(ErrorCode.NOT_FOUND.code(), ErrorCode.NOT_FOUND.message()));
    }

    /** 未映射路径（throw-exception-if-no-handler-found 场景）：同样 404 + 40400 */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNoHandlerFound(NoHandlerFoundException exception) {
        log.warn("no handler found: {} {}", exception.getHttpMethod(), exception.getRequestURL());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiResponse.fail(ErrorCode.NOT_FOUND.code(), ErrorCode.NOT_FOUND.message()));
    }

    /** 上传文件超限（multipart max-file-size）：参数错误，提示可读的大小限制 */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse<Void>> handleMaxUploadSize(MaxUploadSizeExceededException exception) {
        log.warn("upload size exceeded: {}", exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiResponse.fail(ErrorCode.PARAM_ERROR.code(), "文件大小超过限制（单文件最大 1MB）"));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleUnexpectedException(Exception exception) {
        log.error("unexpected error", exception);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.fail(ErrorCode.INTERNAL_ERROR.code(), ErrorCode.INTERNAL_ERROR.message()));
    }

    private HttpStatus httpStatus(ErrorCode errorCode) {
        return switch (errorCode) {
            case TOO_MANY_REQUESTS -> HttpStatus.TOO_MANY_REQUESTS;
            case AI_UNAVAILABLE, SERVICE_UNAVAILABLE -> HttpStatus.SERVICE_UNAVAILABLE;
            default -> HttpStatus.OK;
        };
    }
}
