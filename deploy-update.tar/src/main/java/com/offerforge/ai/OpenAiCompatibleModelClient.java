package com.offerforge.ai;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.offerforge.common.ErrorCode;
import com.offerforge.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.net.HttpURLConnection;
import java.net.URI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@Conditional(AiClientConditions.OpenAiCompatibleAiModel.class)
public class OpenAiCompatibleModelClient implements AiModelClient {

    private static final Logger log = LoggerFactory.getLogger(OpenAiCompatibleModelClient.class);
    private static final Pattern SCORE_PATTERN = Pattern.compile("SCORE\\s*[:：]\\s*(\\d+)");

    private final AiProperties properties;
    private final ObjectMapper objectMapper;
    private final RestClient restClient;

    public OpenAiCompatibleModelClient(AiProperties properties) {
        this.properties = properties;
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        Duration timeout = Duration.ofSeconds(properties.getTimeoutSeconds());
        requestFactory.setConnectTimeout(timeout);
        requestFactory.setReadTimeout(timeout);
        String baseUrl = properties.getBaseUrl();
        this.restClient = RestClient.builder()
                .baseUrl(isBlank(baseUrl) ? "http://localhost" : baseUrl)
                .requestFactory(requestFactory)
                .build();
    }

    @Override
    public AiTextResult generateText(List<ChatMessage> messages) {
        LlmCredentials credentials = LlmCallContext.current();
        String baseUrl = effectiveBaseUrl(credentials);
        String apiKey = effectiveApiKey(credentials);
        String model = effectiveModel(credentials);
        ensureConfigured(baseUrl, apiKey, model);
        long startedAt = System.currentTimeMillis();
        for (int attempt = 0; attempt <= properties.getMaxRetries(); attempt++) {
            try {
                String responseBody = restClient.post()
                        .uri(stripTrailingSlash(baseUrl) + "/chat/completions")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(buildRequestBody(messages, model))
                        .retrieve()
                        .body(String.class);
                ProviderResponse response = parseProviderResponse(responseBody);
                if (response == null || response.choices() == null || response.choices().isEmpty()
                        || response.choices().get(0).message() == null) {
                    throw new BusinessException(ErrorCode.INTERNAL_ERROR, "模型服务返回格式异常");
                }
                String content = response.choices().get(0).message().content();
                String requestId = response.id() == null || response.id().isBlank()
                        ? UUID.randomUUID().toString() : response.id();
                Integer inputTokens = response.usage() == null ? null : response.usage().inputTokens();
                Integer outputTokens = response.usage() == null ? null : response.usage().outputTokens();
                log.info("qa stage=llm mode=text providerRequestId={} model={} keySource={} elapsedMs={} inputTokens={} outputTokens={}",
                        requestId, model, keySource(credentials), System.currentTimeMillis() - startedAt,
                        inputTokens, outputTokens);
                LlmCallContext.recordUsage(inputTokens, outputTokens);
                return new AiTextResult(content == null ? "" : content, requestId, inputTokens, outputTokens);
            } catch (RestClientResponseException exception) {
                if (isRetryable(exception) && attempt < properties.getMaxRetries()) {
                    backoff(attempt);
                    continue;
                }
                log.warn("qa stage=llm mode=text status=failed model={} httpStatus={} elapsedMs={}",
                        model, exception.getStatusCode().value(),
                        System.currentTimeMillis() - startedAt);
                throw unavailable();
            } catch (ResourceAccessException exception) {
                if (attempt < properties.getMaxRetries()) {
                    backoff(attempt);
                    continue;
                }
                log.warn("qa stage=llm mode=text status=unavailable model={} elapsedMs={}",
                        model, System.currentTimeMillis() - startedAt);
                throw unavailable();
            }
        }
        throw unavailable();
    }

    Map<String, Object> buildRequestBody(List<ChatMessage> messages) {
        return buildRequestBody(messages, properties.getModel());
    }

    Map<String, Object> buildRequestBody(List<ChatMessage> messages, String model) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("messages", messages.stream()
                .map(message -> Map.of("role", message.providerRole(), "content", message.content()))
                .toList());
        body.put("temperature", 0.2);
        body.put("max_tokens", properties.getMaxOutputTokens());
        return body;
    }

    @Override
    public void generateStream(List<ChatMessage> messages, AiStreamChunkConsumer chunkConsumer) throws IOException {
        LlmCredentials credentials = LlmCallContext.current();
        String baseUrl = effectiveBaseUrl(credentials);
        String apiKey = effectiveApiKey(credentials);
        String model = effectiveModel(credentials);
        ensureConfigured(baseUrl, apiKey, model);
        long startedAt = System.currentTimeMillis();
        HttpURLConnection connection = null;
        try {
            URI endpoint = URI.create(stripTrailingSlash(baseUrl) + "/chat/completions");
            connection = (HttpURLConnection) endpoint.toURL().openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setConnectTimeout((int) Duration.ofSeconds(properties.getTimeoutSeconds()).toMillis());
            connection.setReadTimeout((int) Duration.ofSeconds(properties.getStreamReadTimeoutSeconds()).toMillis());
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey);
            connection.setRequestProperty(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            connection.setRequestProperty(HttpHeaders.ACCEPT, MediaType.TEXT_EVENT_STREAM_VALUE);
            byte[] requestBody = objectMapper.writeValueAsBytes(buildStreamRequestBody(messages, model));
            try (var output = connection.getOutputStream()) {
                output.write(requestBody);
            }

            int status = connection.getResponseCode();
            if (status >= 400) {
                log.warn("qa stage=llm mode=stream status=failed model={} httpStatus={}",
                        model, status);
                throw unavailable();
            }
            try (InputStream input = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.startsWith("data:")) {
                        continue;
                    }
                    String data = line.substring("data:".length()).trim();
                    if ("[DONE]".equals(data)) {
                        log.info("qa stage=llm mode=stream status=completed model={} keySource={} elapsedMs={}",
                                model, keySource(credentials), System.currentTimeMillis() - startedAt);
                        return;
                    }
                    emitDeltaContent(data, chunkConsumer);
                }
            }
        } catch (JsonProcessingException exception) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "模型服务流式返回格式异常");
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @Override
    public AiEvaluation evaluateAnswer(String question, String candidateAnswer, String userAnswer) {
        String prompt = """
                你是 Java 后端面试官评分器。请根据面试题与候选人回答给出 0-10 的整数评分。
                输出格式必须为：SCORE: 分数 换行 COMMENT: 一句话简评。
                面试题：%s
                参考答案：%s
                候选人回答：%s
                """.formatted(
                question,
                candidateAnswer == null || candidateAnswer.isBlank() ? "（无标准答案，按项目经验与表达评估）" : candidateAnswer,
                userAnswer == null ? "" : userAnswer);
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        Matcher matcher = SCORE_PATTERN.matcher(result.content());
        if (!matcher.find()) {
            log.warn("qa stage=llm mode=evaluate status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
            return new AiEvaluation(5, "评分解析失败，按中等处理");
        }
        int score;
        try {
            // \d+ 不限位数，超过 Integer.MAX_VALUE 时 parseInt 会抛 NFE，需先解析再做范围钳制
            score = Math.max(0, Math.min(10, Integer.parseInt(matcher.group(1))));
        } catch (NumberFormatException exception) {
            log.warn("qa stage=llm mode=evaluate status=score-overflow model={} requestId={}",
                    properties.getModel(), result.requestId());
            score = 5;
        }
        return new AiEvaluation(score, result.content());
    }

    @Override
    public AnswerEvaluation evaluateAnswerDetail(String question, String knowledgePoint, String candidateAnswer, String userAnswer) {
        return evaluateAnswerDetail(question, knowledgePoint, candidateAnswer, userAnswer, false);
    }

    @Override
    public AnswerEvaluation evaluateAnswerDetail(String question, String knowledgePoint, String candidateAnswer,
                                                 String userAnswer, boolean detailed) {
        String detailedRequirement = detailed ? """

                另外请提供详细反馈字段：
                - "goodPoints"：回答中的亮点/说对的关键点（字符串数组，可为空）
                - "badPoints"：回答中的不足/错误/遗漏点（字符串数组，可为空）
                - "improvedAnswer"：一份完整的参考改进回答（字符串，针对原问题给出条理清晰的标准回答）
                """ : "";
        String prompt = """
                你是一个资深技术面试官，正在评估候选人的回答。

                问题：%s
                考察知识点：%s
                标准答案要点：%s
                候选人回答：%s

                评分规则：
                1. 准确性（accuracy）：回答中的技术事实是否正确，有无明显错误
                2. 完整性（completeness）：是否覆盖了标准答案中的关键要点
                3. 表达清晰度（clarity）：回答是否条理清晰、逻辑连贯
                4. 深度（depth）：是否有深入分析、原理剖析或延伸思考，而非仅停留在表面
                5. 若候选人回答是“不知道/不清楚/不了解/不会/忘了”等无效回答，
                   各维度应给低分（0-2），不得给出任何正面评价，feedback 应指出未提供有效回答并给出学习方向

                请返回 JSON 格式（分值均为 0-10 数字）：
                {
                  "accuracy": 数字,
                  "completeness": 数字,
                  "clarity": 数字,
                  "depth": 数字,
                  "overall": 数字,
                  "keyPoints": ["应覆盖的关键要点1"],
                  "missedPoints": ["遗漏的要点1"],
                  "wrongPoints": ["错误的说法1"],
                  "feedback": "2-3句话的综合点评，指出亮点和不足"%s
                }
                只输出 JSON 本身，不要输出其他内容。
                """.formatted(
                question,
                knowledgePoint == null || knowledgePoint.isBlank() ? "（未指定）" : knowledgePoint,
                referenceText(candidateAnswer),
                userAnswer == null ? "" : userAnswer,
                detailedRequirement);
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        AnswerEvaluation parsed = parseAnswerEvaluation(result.content());
        if (parsed == null) {
            log.warn("qa stage=llm mode=evaluate-detail status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
            return new AnswerEvaluation(5, 5, 5, 5, 5, List.of(), List.of(), List.of(),
                    "评估结果解析失败，按中等处理", null, null, null);
        }
        return parsed;
    }

    @Override
    public AnswerEvaluation evaluateIntroDetail(String intro, String position) {
        // 开场自我介绍评估：无知识点标准答案，按信息完整度/表达结构/岗位相关性评估，与知识题评分分离
        String prompt = """
                你是一位资深技术面试官，正在评估候选人的开场自我介绍。
                注意：这不是知识问答，没有标准答案，不得以知识点正确性评分。

                候选人求职岗位：%s
                候选人自我介绍：%s

                评分维度（分值均为 0-10 数字）：
                1. accuracy：经历描述的具体可信度（是否有具体职责、技术选型、数据量级等可验证细节，而非泛泛而谈）
                2. completeness：信息完整度（教育/工作/实习背景、项目或实践经历、技术栈三方面是否齐备）
                3. clarity：表达是否条理清晰、重点突出、逻辑连贯
                4. depth：项目与经历是否有深度（技术难点、解决方案、量化成果），与目标岗位的相关性如何
                5. 若自我介绍内容几乎为空或与求职无关，各维度应给低分，feedback 指出应补充的方向

                请返回 JSON 格式：
                {
                  "accuracy": 数字,
                  "completeness": 数字,
                  "clarity": 数字,
                  "depth": 数字,
                  "overall": 数字,
                  "keyPoints": ["自我介绍应包含的信息维度1"],
                  "missedPoints": ["候选人尚未提供的信息1"],
                  "wrongPoints": [],
                  "feedback": "2-3句话的综合点评，基于候选人实际提供的信息与表达，指出亮点和可补充的方向",
                  "goodPoints": ["自我介绍中的亮点1"],
                  "badPoints": ["自我介绍中的不足1"],
                  "improvedAnswer": "一份基于候选人自述信息润色后的改进示范自我介绍（保留其真实信息，不得虚构经历）"
                }
                只输出 JSON 本身，不要输出其他内容。
                """.formatted(
                position == null || position.isBlank() ? "（未指定）" : position,
                intro == null ? "" : intro);
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        AnswerEvaluation parsed = parseAnswerEvaluation(result.content());
        if (parsed == null) {
            log.warn("qa stage=llm mode=evaluate-intro status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
            return null;
        }
        return parsed;
    }

    @Override
    public String generateFollowUpQuestion(String prompt) {
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        String content = result.content() == null ? "" : result.content().trim();
        return content.isEmpty() ? "你能针对这个知识点再展开讲讲吗？" : content;
    }

    @Override
    public String generateIntroFollowUp(String prompt) {
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        String content = result.content() == null ? "" : result.content().trim();
        // 提示词约定：信息充分时输出 NONE；其余输出（含模型不守约的啰嗦前缀）均视为补充提问
        if (content.isEmpty() || "NONE".equalsIgnoreCase(content)) {
            return null;
        }
        return content;
    }

    @Override
    public ReportSummary generateReportSummary(String prompt) {
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        ReportSummary parsed = parseReportSummary(result.content());
        if (parsed == null) {
            log.warn("qa stage=llm mode=report-summary status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
        }
        return parsed;
    }

    @Override
    public String parseResume(String rawText) {
        if (rawText == null || rawText.isBlank()) {
            return null;
        }
        String prompt = """
                你是简历解析器。请将以下简历纯文本结构化，返回 JSON：
                {
                  "name": "姓名",
                  "education": "教育经历文本",
                  "skills": "技能清单文本",
                  "projects": [
                    {"projectName": "项目名称", "role": "角色", "duration": "时间段",
                     "description": "项目描述", "techStack": "技术栈",
                     "highlights": "亮点成果", "challenges": "遇到的挑战"}
                  ],
                  "internships": "实习经历文本",
                  "selfIntroduction": "自我介绍"
                }
                无法识别的字段置为空字符串或空数组；只输出 JSON 本身。
                简历原文：
                %s
                """.formatted(rawText);
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        String json = extractJsonObject(result.content() == null ? "" : result.content());
        if (json == null) {
            log.warn("qa stage=llm mode=resume-parse status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
        }
        return json;
    }

    @Override
    public List<AiGeneratedQuestion> generateProjectQuestions(String prompt) {
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        List<AiGeneratedQuestion> parsed = parseGeneratedQuestions(result.content());
        if (parsed.isEmpty()) {
            log.warn("qa stage=llm mode=project-questions status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
        }
        return parsed;
    }

    @Override
    public AiGeneratedQuestion generateDeepQuestion(String prompt) {
        AiTextResult result = generateText(List.of(ChatMessage.user(prompt)));
        AiGeneratedQuestion parsed = parseGeneratedQuestion(result.content());
        if (parsed == null) {
            log.warn("qa stage=llm mode=deep-question status=unparsable model={} requestId={}",
                    properties.getModel(), result.requestId());
        }
        return parsed;
    }

    private String referenceText(String candidateAnswer) {
        return candidateAnswer == null || candidateAnswer.isBlank()
                ? "（无标准答案，按项目经验与表达评估）" : candidateAnswer;
    }

    /**
     * 解析评估 JSON：四维度钳制 0-10，overall 由服务端按权重 0.35/0.25/0.20/0.20 重算（不信任模型自报值）。
     * 解析失败返回 null，由调用方兜底。
     */
    AnswerEvaluation parseAnswerEvaluation(String content) {
        if (content == null || content.isBlank()) {
            return null;
        }
        String json = extractJsonObject(content);
        if (json == null) {
            return null;
        }
        try {
            JsonNode node = objectMapper.readTree(json);
            double accuracy = clampScore(node, "accuracy");
            double completeness = clampScore(node, "completeness");
            double clarity = clampScore(node, "clarity");
            double depth = clampScore(node, "depth");
            double overall = Math.round(
                    (accuracy * 0.35 + completeness * 0.25 + clarity * 0.20 + depth * 0.20) * 10.0) / 10.0;
            String feedback = node.path("feedback").asText("");
            // 详细反馈字段仅训练模式详细评估时产出，缺失置 null（使用处判空）
            List<String> goodPoints = node.has("goodPoints") ? readPoints(node, "goodPoints") : null;
            List<String> badPoints = node.has("badPoints") ? readPoints(node, "badPoints") : null;
            String improvedAnswer = node.path("improvedAnswer").asText("");
            return new AnswerEvaluation(accuracy, completeness, clarity, depth, overall,
                    readPoints(node, "keyPoints"), readPoints(node, "missedPoints"), readPoints(node, "wrongPoints"),
                    feedback.isBlank() ? "评估完成" : feedback,
                    goodPoints, badPoints, improvedAnswer.isBlank() ? null : improvedAnswer);
        } catch (JsonProcessingException exception) {
            return null;
        }
    }

    /**
     * 解析报告摘要 JSON：只取文本清单（每类最多 5 条）；格式非法或三类全空返回 null，由调用方兜底。
     */
    ReportSummary parseReportSummary(String content) {
        if (content == null || content.isBlank()) {
            return null;
        }
        String json = extractJsonObject(content);
        if (json == null) {
            return null;
        }
        try {
            JsonNode node = objectMapper.readTree(json);
            List<String> strengths = readPoints(node, "strengths", 5);
            List<String> weaknesses = readPoints(node, "weaknesses", 5);
            List<String> suggestions = readPoints(node, "suggestions", 5);
            if (strengths.isEmpty() && weaknesses.isEmpty() && suggestions.isEmpty()) {
                return null;
            }
            return new ReportSummary(strengths, weaknesses, suggestions);
        } catch (JsonProcessingException exception) {
            return null;
        }
    }

    /**
     * 解析项目题生成结果：{questions:[...]}；题面为空则丢弃，非法 JSON 返回空列表。
     */
    List<AiGeneratedQuestion> parseGeneratedQuestions(String content) {
        if (content == null || content.isBlank()) {
            return List.of();
        }
        String json = extractJsonObject(content);
        if (json == null) {
            return List.of();
        }
        try {
            JsonNode node = objectMapper.readTree(json);
            JsonNode questions = node.path("questions");
            if (!questions.isArray()) {
                return List.of();
            }
            List<AiGeneratedQuestion> parsed = new ArrayList<>();
            for (JsonNode item : questions) {
                AiGeneratedQuestion question = toGeneratedQuestion(item);
                if (question != null) {
                    parsed.add(question);
                }
            }
            return parsed;
        } catch (JsonProcessingException exception) {
            return List.of();
        }
    }

    /**
     * 解析单对象深挖题生成结果；题面为空或非法 JSON 返回 null。
     */
    AiGeneratedQuestion parseGeneratedQuestion(String content) {
        if (content == null || content.isBlank()) {
            return null;
        }
        String json = extractJsonObject(content);
        if (json == null) {
            return null;
        }
        try {
            return toGeneratedQuestion(objectMapper.readTree(json));
        } catch (JsonProcessingException exception) {
            return null;
        }
    }

    private AiGeneratedQuestion toGeneratedQuestion(JsonNode node) {
        String question = node.path("question").asText("").trim();
        if (question.isEmpty()) {
            return null;
        }
        String knowledgePoint = node.path("knowledgePoint").asText("").trim();
        String difficulty = node.path("difficulty").asText("").trim().toUpperCase();
        return new AiGeneratedQuestion(question, knowledgePoint, readPoints(node, "referenceAnswer", 8), difficulty);
    }

    private String extractJsonObject(String content) {
        int start = content.indexOf('{');
        int end = content.lastIndexOf('}');
        return start >= 0 && end > start ? content.substring(start, end + 1) : null;
    }

    private double clampScore(JsonNode node, String field) {
        double value = node.path(field).isNumber() ? node.path(field).asDouble() : 5.0;
        return Math.max(0, Math.min(10, value));
    }

    private List<String> readPoints(JsonNode node, String field) {
        return readPoints(node, field, 10);
    }

    private List<String> readPoints(JsonNode node, String field, int limit) {
        List<String> points = new ArrayList<>();
        JsonNode array = node.path(field);
        if (array.isArray()) {
            for (JsonNode item : array) {
                String text = item.asText("").trim();
                if (!text.isEmpty() && points.size() < limit) {
                    points.add(text);
                }
            }
        }
        return points;
    }

    Map<String, Object> buildStreamRequestBody(List<ChatMessage> messages) {
        return buildStreamRequestBody(messages, properties.getModel());
    }

    Map<String, Object> buildStreamRequestBody(List<ChatMessage> messages, String model) {
        Map<String, Object> body = buildRequestBody(messages, model);
        body.put("stream", true);
        // 请求末尾 chunk 携带 usage，用于 token 消耗统计（不支持的实现会忽略该参数）
        body.put("stream_options", Map.of("include_usage", true));
        return body;
    }

    private void emitDeltaContent(String data, AiStreamChunkConsumer chunkConsumer) throws IOException {
        try {
            ProviderStreamChunk chunk = objectMapper.readValue(data, ProviderStreamChunk.class);
            if (chunk.usage() != null) {
                LlmCallContext.recordUsage(chunk.usage().inputTokens(), chunk.usage().outputTokens());
            }
            if (chunk.choices() == null || chunk.choices().isEmpty() || chunk.choices().get(0).delta() == null) {
                return;
            }
            String delta = chunk.choices().get(0).delta().content();
            if (delta != null && !delta.isEmpty()) {
                chunkConsumer.accept(delta);
            }
        } catch (JsonProcessingException exception) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "模型服务流式返回格式异常");
        }
    }

    private String stripTrailingSlash(String value) {
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private ProviderResponse parseProviderResponse(String responseBody) {
        try {
            return objectMapper.readValue(responseBody, ProviderResponse.class);
        } catch (JsonProcessingException exception) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "模型服务返回格式异常");
        }
    }

    private void ensureConfigured(String baseUrl, String apiKey, String model) {
        if (isBlank(baseUrl) || isBlank(apiKey) || isBlank(model)) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "模型服务未完成配置");
        }
    }

    /** 凭据优先，缺省回退系统配置 */
    private String effectiveBaseUrl(LlmCredentials credentials) {
        return credentials != null && !isBlank(credentials.baseUrl()) ? credentials.baseUrl() : properties.getBaseUrl();
    }

    private String effectiveApiKey(LlmCredentials credentials) {
        return credentials != null && !isBlank(credentials.apiKey()) ? credentials.apiKey() : properties.getApiKey();
    }

    private String effectiveModel(LlmCredentials credentials) {
        return credentials != null && !isBlank(credentials.model()) ? credentials.model() : properties.getModel();
    }

    private String keySource(LlmCredentials credentials) {
        return credentials == null ? "system" : "user";
    }

    private boolean isRetryable(RestClientResponseException exception) {
        int status = exception.getStatusCode().value();
        return status == 429 || status >= 500;
    }

    private void backoff(int attempt) {
        try {
            Thread.sleep(200L * (attempt + 1));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw unavailable();
        }
    }

    private BusinessException unavailable() {
        return new BusinessException(ErrorCode.AI_UNAVAILABLE, "AI 响应超时，请重试");
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private record ProviderMessage(String role, String content) {
    }

    private record ProviderResponse(String id, List<ProviderChoice> choices, ProviderUsage usage) {
    }

    private record ProviderChoice(ProviderMessage message) {
    }

    private record ProviderStreamChunk(List<ProviderStreamChoice> choices, ProviderUsage usage) {
    }

    private record ProviderStreamChoice(ProviderMessage delta) {
    }

    private record ProviderUsage(
            @JsonProperty("prompt_tokens") Integer inputTokens,
            @JsonProperty("completion_tokens") Integer outputTokens
    ) {
    }
}
