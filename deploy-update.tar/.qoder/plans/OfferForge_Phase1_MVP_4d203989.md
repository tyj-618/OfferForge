# OfferForge Phase 1 MVP 执行计划

## 总体结构

沿用 UniNook 的分包与配置风格，包名 `com.offerforge`，Maven 单模块：

```
OfferForge/
├── pom.xml                          # Spring Boot 4.0.6 parent, Java 17
├── docker-compose.yml               # mysql + redis + elasticsearch(profile: search)
├── .env.example / .gitignore
└── src
    ├── main/java/com/offerforge/
    │   ├── OfferForgeApplication.java
    │   ├── common/                  # ApiResponse, ErrorCode, JacksonConfig
    │   ├── exception/               # BusinessException, GlobalExceptionHandler
    │   ├── auth/                    # 登录鉴权（对齐 UniNook 模式）
    │   ├── ai/                      # LLM / Embedding 客户端层
    │   ├── knowledge/               # 知识库实体、仓储、服务、ES 索引
    │   └── qa/                      # 单轮问答
    ├── main/resources/
    │   ├── application.yaml
    │   ├── db/schema.sql            # MySQL 容器初始化 + 生产 DDL
    │   └── knowledge/java-backend-questions.json   # 50 道八股题
    └── test/...                     # application-test.yaml(H2) + 各测试
```

## 依赖与基础设施

- pom.xml：spring-boot-starter-web / validation / data-jpa / data-redis / actuator、spring-security-crypto、jackson、mysql-connector-j(runtime)、h2(test)、spring-boot-starter-test。不引入 MyBatis-Plus（本任务明确要求 JPA）。
- docker-compose.yml（端口全部避开 UniNook 容器）：
  - mysql:8.4 → 宿主机 `127.0.0.1:3308`，库名 `offerforge`，挂载 `db/schema.sql` 初始化
  - redis:7.4-alpine → `127.0.0.1:6380`
  - elasticsearch:8.19.8（profile `search`）→ `127.0.0.1:9201`，单节点、关安全
- application.yaml：数据源/Redis 走 `OFFERFORGE_*` 环境变量；`spring.jpa.hibernate.ddl-auto: none`（DDL 由 schema.sql 管理）；服务端口默认 `8081`。
- 配置前缀 `offerforge.ai` / `offerforge.search` / `offerforge.auth`，全部带环境变量占位符，默认值 `ai.provider=mock`、`search.enabled=false`（零外部依赖即可启动）。

## common + exception

- `ApiResponse<T>`（code/message/data，success 时 code=0）、`ErrorCode` 枚举（PARAM_ERROR/AUTH_FAILED/USERNAME_EXISTS/UNAUTHORIZED/FORBIDDEN/NOT_FOUND/INTERNAL_ERROR，编码与 UniNook 一致）
- `BusinessException` + `GlobalExceptionHandler`（业务异常、参数校验、兜底 50000）

## auth 模块（Phase 1 就搭鉴权）

对齐 UniNook：`AuthController`（register/login/refresh/logout，refresh token 走 HttpOnly Cookie）、`AuthService`（BCrypt、登录时序补偿）、`CurrentUserService.requireUserId(authorization)` —— 所有受保护接口的用户身份只从这里取。
- TokenStore 接口 + `InMemoryTokenStore`（默认）+ `RedisTokenStore`（@Profile("redis")），`TokenGenerator`（UUID）、`LoginRateLimiter`（内存版）。
- `UserEntity` + `UserRepository`（JPA）：username 唯一、password 哈希、nickname、status。
- `/api/auth/*` 白名单，其余接口登录态校验。

## ai 模块（手写 OpenAI 兼容客户端 + Mock）

- `ChatMessage`（role/content）、`AiTextResult`（content/requestId/tokens）。
- `AiModelClient` 接口：Phase 1 只需 `generateText(messages)`（后续 Phase 再扩展流式/工具调用）。
- `MockAiModelClient`（`provider=mock`，matchIfMissing）：确定性返回模拟回答，并把 prompt 中 `[ref: {id}]` 标记的知识条目 ID 回显，供测试断言引用关系。
- `OpenAiCompatibleModelClient`（`provider=openai-compatible`）：RestClient + Bearer Key + 重试（429/5xx 指数退避）+ 超时 + 未配置即抛 BusinessException；日志打 requestId/耗时/tokens，模式同 UniNook。
- `EmbeddingClient` 接口：`MockEmbeddingClient`（基于关键词哈希的确定性向量，保证"相同问题文本相似度高"，支撑检索测试）+ `OpenAiCompatibleEmbeddingClient`（/embeddings，维度校验默认 1024，对应百炼 text-embedding-v4）。
- `AiProperties` / `SearchProperties`。

## knowledge 模块（知识库）

- `KnowledgeItem` JPA 实体：id、question、answer(TEXT)、category、tags（CSV 字符串）、createdAt；表 `knowledge_item`，question 唯一。
- `KnowledgeRepository extends JpaRepository<KnowledgeItem, Long>`，含 `findByQuestion`、按 question/tags/category LIKE 的关键词查询。
- `KnowledgeIndexClient`：复刻 `ElasticsearchPostIndexClient` 模式 —— RestClient 直连 ES，索引 `offerforge-knowledge`（dense_vector dims=配置值、cosine、strict mapping），提供 `upsert`（含 embedding）、`searchByVector`（kNN）、`searchByKeyword`（multi_match）、懒建索引；`search.enabled=false` 时不装配。
- `KnowledgeService`：
  - `importBuiltinKnowledge()`：读取 classpath `knowledge/java-backend-questions.json`（50 条，我生成，覆盖集合/并发/JVM/MySQL/Redis/网络/Spring/设计思想等高频考点，每条含 question/answer/category/tags），按 question 幂等导入 MySQL，再逐条 embedding 写入 ES（ES 未启用时跳过向量写入）。
  - `search(query, limit)`：ES 启用 → embed(query) → kNN 取 ID → 回查 MySQL（MySQL 为事实源）；ES 未启用 → MySQL 关键词兜底检索。返回 `RetrievedKnowledge(itemId, question, answer, category, score)`。
- 导入入口：`POST /api/knowledge/import`（需登录，幂等），便于初始化与测试。

## qa 模块（单轮问答）

- `POST /api/qa/ask`，请求体 `{question}`，需 Bearer 登录态。
- `QaService.ask(userId, question)`：参数校验 → `knowledgeService.search(question, 5)` → `QaPromptBuilder` 拼 prompt（system：Java 后端面试知识助手人设 + 只依据给定知识作答 + 未覆盖时明示；user：问题 + 编号知识块，每块 `[ref: {id}]` 题面+答案节选）→ `aiModelClient.generateText` → 组装 `QaResponse(answer, referencedKnowledgeIds, question)`。
- 引用 ID 从 prompt 知识块解析回填，不信任 LLM 输出（安全约束落地）。

## 数据与配置文件

- `db/schema.sql`：`users`、`knowledge_item` 两张表 DDL。
- `.env.example`：OFFERFORGE_DB_*、OFFERFORGE_REDIS_*、OFFERFORGE_AI_*（百炼 base-url https://dashscope.aliyuncs.com/compatible-mode/v1、model 示例 qwen-plus）、OFFERFORGE_SEARCH_*（embedding-model text-embedding-v4、dimensions 1024）。
- test：`application-test.yaml` 用 H2（MODE=MySQL）+ `ddl-auto: create-drop` + mock provider + search 关闭。

## 测试计划（mvnw test 全绿）

1. `KnowledgeImportTests`：导入后库内 50 条且字段完整；重复导入不产生重复（幂等）。
2. `KnowledgeSearchTests`：mock embedding + ES 关闭下的关键词兜底检索命中"HashMap 底层原理"等目标条目；`KnowledgeIndexClient` 文档体构建单测（不起真实 ES）。
3. `QaApiIntegrationTests`（@SpringBootTest RANDOM_PORT + test profile）：注册→登录→提问→code=0、answer 非空、referencedKnowledgeIds 与检索结果一致；无 token 提问返回 40100。
4. 单元测试：`QaPromptBuilderTests`（prompt 含知识块与格式约束）、`OpenAiCompatibleModelClientTests`（请求体构建/重试语义）、鉴权基础用例（注册重复用户名、错误密码）。

## 假设与边界

- 本次不含 Vue3 前端（任务列表未包含，留待后续指令）。
- 50 道八股题由我生成，答案以精炼要点形式呈现（每题约 100-200 字），足以支撑检索与 prompt 拼装演示。
- ES 真实连通的端到端验证依赖本地 `docker compose --profile search`；CI/单测以 mock + H2 保证全绿，不依赖外部服务。
- Redis 在 Phase 1 仅用于 `RedisTokenStore`（redis profile），对话历史 Redis 存储留待 Phase 2。